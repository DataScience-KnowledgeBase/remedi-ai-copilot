# Copyright 2026 Google LLC
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

from __future__ import annotations

import asyncio
from contextlib import aclosing
import contextvars
import inspect
import logging
from pathlib import Path
import queue
from types import TracebackType
from typing import Any
from typing import AsyncGenerator
from typing import Callable
from typing import cast
from typing import Generator
from typing import List
from typing import Literal
from typing import Optional
from typing import TYPE_CHECKING
import warnings

from google.genai import types
from typing_extensions import Self

from .agents.base_agent import BaseAgent
from .agents.context_cache_config import ContextCacheConfig
from .agents.invocation_context import InvocationContext
from .agents.invocation_context import new_invocation_context_id
from .agents.llm.task._finish_task_tool import FINISH_TASK_ERROR_RESULT
from .agents.llm.task._finish_task_tool import FINISH_TASK_SUCCESS_RESULT
from .agents.llm.task._finish_task_tool import FINISH_TASK_TOOL_NAME
from .agents.run_config import RunConfig
from .artifacts.base_artifact_service import BaseArtifactService
from .auth.credential_service.base_credential_service import BaseCredentialService
from .errors._stale_session_error import StaleSessionError
from .errors.session_not_found_error import SessionNotFoundError
from .events._abort_events import _build_abort_events
from .events._abort_events import _is_abort_event
from .events._internal_metadata import internal_metadata
from .events._internal_metadata import without_internal_metadata
from .events._rewind_events import _apply_rewinds
from .events.event import Event
from .events.event_actions import EventActions
from .live.live_request_queue import LiveRequestQueue
from .memory.base_memory_service import BaseMemoryService
from .platform.thread import create_thread
from .plugins.base_plugin import BasePlugin
from .plugins.plugin_manager import PluginManager
from .sessions.base_session_service import BaseSessionService
from .sessions.base_session_service import GetSessionConfig
from .sessions.session import Session
from .tools.base_toolset import BaseToolset
from .utils import _lazy
from .utils._agent_mode import AgentMode as _AgentMode
from .utils._debug_output import print_event
from .utils._runner_utils import _notify_run_error
from .workflow._base_node import BaseNode

if TYPE_CHECKING:
  from .apps.app import App
  from .apps.app import ResumabilityConfig
  from .telemetry.tracing import tracer as tracer

logger = logging.getLogger('google_adk.' + __name__)

_EventQueueItem = tuple[object, asyncio.Event | None]


# App names already told that agent transfer runs without a context cache.
_UNCACHED_TRANSFER_APPS: set[str] = set()

# Sentinel cancellation message indicating synchronous run() caller stopped
# iterating early.
_CALLER_CLOSED_EARLY_MSG = 'adk-runner-caller-closed-early'


def _find_active_task_scope(session: Session) -> Optional[tuple[str, str]]:
  """Walk session backwards; find the active paused task agent's scope.

  Two flavors of task scope:
    * FC delegation (chat coordinator → task agent via function call):
      scope = ``fc.id``, opened by an unresolved task FC.
    * Workflow node (task-mode LlmAgent dispatched as a graph node):
      scope = ``<node_name>@<run_id>``, stamped on every event the
      task agent emits.

  Both close on a terminal ``finish_task`` FunctionResponse containing a
  'result' key matching ``FINISH_TASK_SUCCESS_RESULT`` or
  ``FINISH_TASK_ERROR_RESULT``. A FunctionResponse containing an 'error' key
  (indicating a tool validation failure) does NOT close the scope: the task
  agent is still active, will see the validation error, and retry. Scopes whose
  invocation was aborted are also closed, since the task agent was cancelled
  without calling ``finish_task``. Walking backward, the first non-empty scope
  we encounter that hasn't been closed is the paused task awaiting the user's
  next reply.

  Used by ``Runner._append_user_event`` to scope the new user message
  to that task agent's view.

  Returns:
    A tuple of (isolation_scope, invocation_id) for the active task if found,
    or None if no active task scope is found.
  """
  # Pass 1: Scan forward to find all scopes that have successfully finished.
  # We must do this in a separate pass because walking backward directly would
  # hit post-finish events (like status updates or duplicate FRs) before hitting
  # the older success FR, falsely indicating the scope is still active.
  live_events = _apply_rewinds(session.events)
  finished_scopes: set[str] = set()
  aborted_invocations: set[str] = set()
  for event in live_events:
    if _is_abort_event(event):
      aborted_invocations.add(event.invocation_id)
    scope = event.isolation_scope
    if not scope:
      continue
    if event.content and event.content.parts:
      for part in event.content.parts:
        fr = part.function_response
        if fr and fr.name == FINISH_TASK_TOOL_NAME:
          response = fr.response or {}
          if response.get('result') in (
              FINISH_TASK_SUCCESS_RESULT,
              FINISH_TASK_ERROR_RESULT,
          ):
            finished_scopes.add(scope)
          break

  # Pass 2: Walk backward to find the latest active scope that is not finished.
  for event in reversed(live_events):
    scope = event.isolation_scope
    if not scope:
      continue
    if (
        scope not in finished_scopes
        and event.invocation_id not in aborted_invocations
    ):
      return scope, event.invocation_id
  return None


def _get_function_responses_from_content(
    content: types.Content | None,
) -> list[types.FunctionResponse]:
  if not content or not content.parts:
    return []
  return [
      part.function_response for part in content.parts if part.function_response
  ]


def _session_for_routing(
    session: Session, new_message: types.Content | None
) -> Session:
  """Includes a user FunctionResponse for routing before `new_message` is saved.

  `_find_agent_to_run` runs before `new_message` is appended to
  `session.events`, so a user FunctionResponse must be attached here to route
  back to the agent that issued the FunctionCall.
  """
  if not _get_function_responses_from_content(new_message):
    return session
  filtered_events = _apply_rewinds(session.events)
  if filtered_events and _is_abort_event(filtered_events[-1]):
    return session
  return session.model_copy(
      update={
          'events': [
              *session.events,
              Event(author='user', content=new_message),
          ]
      }
  )


def _apply_run_config_custom_metadata(
    event: Event, run_config: RunConfig | None
) -> None:
  """Merges run-level custom metadata, minus ADK-internal keys, into the event."""
  if not run_config or not run_config.custom_metadata:
    return
  run_metadata = without_internal_metadata(run_config.custom_metadata)
  if not run_metadata:
    return

  event.custom_metadata = {
      **run_metadata,
      **(event.custom_metadata or {}),
  }


def _can_transfer_between_agents(root: Any) -> bool:
  """Reports whether any agent in the tree can transfer to another agent."""
  from .agents import _agent_router

  return _agent_router.can_transfer_between_agents(root)


def _stamp_event_branch_context(ic: InvocationContext, event: Event) -> None:
  """Stamps the event with the branch and isolation scope of its matching function call."""
  from .flows.llm_flows.tools._functions import find_matching_function_call

  if function_call := find_matching_function_call(
      ic._get_events(current_invocation=True), event
  ):
    event.branch = function_call.branch
    if (
        event.isolation_scope is None
        and function_call.isolation_scope is not None
    ):
      event.isolation_scope = function_call.isolation_scope


class Runner:
  """The Runner class is used to run agents.

  It manages the execution of an agent within a session, handling message
  processing, event generation, and interaction with various services like
  artifact storage, session management, and memory.

  Attributes:
      app_name: The application name of the runner.
      agent: The root agent to run.
      artifact_service: The artifact service for the runner.
      plugin_manager: The plugin manager for the runner.
      session_service: The session service for the runner.
      memory_service: The memory service for the runner.
      credential_service: The credential service for the runner.
      context_cache_config: The context cache config for the runner.
      resumability_config: The resumability config for the application.
  """

  app_name: str
  """The app name of the runner."""
  app: App
  """The normalized application configuration."""
  agent: BaseNode = None  # type: ignore[assignment]
  """The root agent or node to run.

  The None default keeps ``Runner.agent`` a real class attribute. Dropping it
  removes ``agent`` from ``dir(Runner)``, which breaks ``Mock(spec=Runner)``
  and ``mock.create_autospec(Runner)`` for callers that touch it.

  Instances are never None, so the declared type stays ``BaseNode``.
  """
  artifact_service: Optional[BaseArtifactService] = None
  """The artifact service for the runner."""
  plugin_manager: PluginManager
  """The plugin manager for the runner."""
  session_service: BaseSessionService
  """The session service for the runner."""
  memory_service: Optional[BaseMemoryService] = None
  """The memory service for the runner."""
  credential_service: Optional[BaseCredentialService] = None
  """The credential service for the runner."""
  context_cache_config: Optional[ContextCacheConfig] = None
  """The context cache config for the runner."""
  resumability_config: Optional[ResumabilityConfig] = None
  """The resumability config for the application."""

  def __init__(
      self,
      *,
      app: Optional[App] = None,
      app_name: Optional[str] = None,
      agent: Optional[BaseAgent] = None,
      node: BaseNode | None = None,
      plugins: Optional[List[BasePlugin]] = None,
      artifact_service: Optional[BaseArtifactService] = None,
      session_service: BaseSessionService,
      memory_service: Optional[BaseMemoryService] = None,
      credential_service: Optional[BaseCredentialService] = None,
      plugin_close_timeout: float = 5.0,
      auto_create_session: bool = False,
  ) -> None:
    """Initializes the Runner.

    Exactly one of `app`, `agent`, or `node` must be provided. When `agent`
    or `node` is provided, the Runner wraps it into an `App` internally.
    Providing `app` is the recommended way to create a runner. When `app` is
    provided, `app_name` can optionally override the app's name.

    Args:
        app: An `App` instance. Mutually exclusive with `agent` and `node`.
        app_name: The application name. Required when `agent` is provided.
          Optional override for `app.name` when `app` is provided. Defaults to
          `node.name` when only `node` is provided.
        agent: The root agent to run. Mutually exclusive with `app` and `node`.
        node: The root node to run. Mutually exclusive with `app` and `agent`.
        plugins: Deprecated. A list of plugins for the runner. Please use the
          `app` argument to provide plugins instead.
        artifact_service: The artifact service for the runner.
        session_service: The session service for the runner.
        memory_service: The memory service for the runner.
        credential_service: The credential service for the runner.
        plugin_close_timeout: The timeout in seconds for plugin close methods.
        auto_create_session: Whether to automatically create a session when not
          found. Defaults to False. If False, a missing session raises
          ValueError with a helpful message.

    Raises:
        ValueError: If more than one of `app`, `agent`, or `node` is provided,
          or if none is provided, or if `agent` is provided without `app_name`.
    """
    app = self._resolve_app(app, app_name, agent, node, plugins)

    # Extract from App — single code path.
    self.app = app
    self.app_name = app_name or app.name
    if app.root_agent is None:
      raise ValueError('App root_agent must be provided.')
    self.agent = app.root_agent
    self.context_cache_config = app.context_cache_config
    self.resumability_config = app.resumability_config
    self.artifact_service = artifact_service
    self.session_service = session_service
    self.memory_service = memory_service
    self.credential_service = credential_service
    self.plugin_manager = PluginManager(
        plugins=app.plugins, close_timeout=plugin_close_timeout
    )
    self.auto_create_session = auto_create_session
    (
        self._agent_origin_app_name,
        self._agent_origin_dir,
    ) = self._infer_agent_origin(cast(BaseAgent, self.agent))
    self._app_name_alignment_hint: Optional[str] = None
    self._enforce_app_name_alignment()
    self._warn_uncached_agent_transfer()

  def _require_root_agent(self) -> BaseAgent:
    """Returns the root as an agent for agent-only execution paths."""
    if not isinstance(self.agent, BaseAgent):
      raise TypeError(
          f'Runner root {self.agent.name!r} is a node, not an agent.'
      )
    return self.agent

  @staticmethod
  def _resolve_app(
      app: Optional[App],
      app_name: Optional[str],
      agent: Optional[BaseAgent],
      node: BaseNode | None,
      plugins: Optional[List[BasePlugin]],
  ) -> App:
    """Validates inputs and normalizes to an App instance.

    Exactly one of ``app``, ``agent``, or ``node`` must be provided.
    When ``agent`` or ``node`` is given, it is wrapped in a new ``App``.

    Returns:
      The resolved ``App`` instance.

    Raises:
      ValueError: If the combination of arguments is invalid.
    """
    # Validate mutual exclusivity.
    provided = sum(x is not None for x in (app, agent, node))
    if provided > 1:
      provided_args = []
      if app is not None:
        provided_args.append(f'app={type(app).__name__}')
      if agent is not None:
        provided_args.append(f'agent={type(agent).__name__}')
      if node is not None:
        provided_args.append(f'node={type(node).__name__}')
      args_str = ', '.join(provided_args)
      raise ValueError(
          'Only one of app, agent, or node may be provided, but got:'
          f' {args_str}. Pass exactly one to Runner().'
      )
    if provided == 0:
      raise ValueError(
          'One of app, agent, or node must be provided. Got none.'
          ' Pass exactly one to Runner().'
      )

    # Handle deprecated plugins argument.
    if plugins is not None:
      if app is not None:
        raise ValueError(
            'When app is provided, plugins should not be provided and should'
            ' be provided in the app instead.'
        )
      warnings.warn(
          'The `plugins` argument is deprecated. Please use the `app` argument'
          ' to provide plugins instead.',
          DeprecationWarning,
      )

    # Lazy import keeps apps.app off the `import google.adk` cold-start path.
    from .apps.app import App

    # Normalize to App — wrap bare agent or node. Uses model_construct to
    # bypass App._validate for the legacy (app_name, agent) API, which v1
    # accepted with arbitrary names and root_agent types. Direct App(name=...)
    # construction still validates strictly.
    if agent is not None:
      if not app_name:
        raise ValueError(
            'app_name is required when agent is provided without app.'
        )
      return App.model_construct(
          name=app_name, root_agent=agent, plugins=plugins or []
      )
    if node is not None:
      node_name: str = getattr(node, 'name', 'default')
      return App.model_construct(
          name=app_name or node_name,
          root_agent=node,
          plugins=plugins or [],
      )
    if app is None:
      raise RuntimeError('Runner app resolution produced no app.')
    return app

  def _infer_agent_origin(
      self, agent: BaseAgent
  ) -> tuple[Optional[str], Optional[Path]]:
    """Infer the origin app name and directory from an agent's module location.

    Returns:
      A tuple of (origin_app_name, origin_path):
        - origin_app_name: The inferred app name (directory name containing the
          agent), or None if inference is not possible/applicable.
        - origin_path: The directory path where the agent is defined, or None
          if the path cannot be determined.

      Both values are None when:
        - The agent has no associated module
        - The agent is defined in google.adk.* (ADK internal modules)
        - The module has no __file__ attribute
    """
    # First, check for metadata set by AgentLoader (most reliable source).
    # AgentLoader sets these attributes when loading agents.
    origin_app_name = getattr(agent, '_adk_origin_app_name', None)
    origin_path = getattr(agent, '_adk_origin_path', None)
    if origin_app_name is not None and origin_path is not None:
      return origin_app_name, origin_path

    # Fall back to heuristic inference for programmatic usage.
    module = inspect.getmodule(agent.__class__)
    if not module:
      return None, None

    # Skip ADK internal modules. When users instantiate LlmAgent directly
    # (not subclassed), inspect.getmodule() returns the ADK module. This
    # could falsely match 'agents' in 'google/adk/agents/' path.
    if module.__name__.startswith('google.adk.'):
      return None, None

    module_file = getattr(module, '__file__', None)
    if not module_file:
      return None, None
    module_path = Path(module_file).resolve()
    project_root = Path.cwd()
    try:
      relative_path = module_path.relative_to(project_root)
    except ValueError:
      return None, module_path.parent
    origin_dir = module_path.parent
    if 'agents' not in relative_path.parts:
      return None, origin_dir
    origin_name = origin_dir.name
    if origin_name.startswith('.'):
      return None, origin_dir
    return origin_name, origin_dir

  def _enforce_app_name_alignment(self) -> None:
    origin_name = self._agent_origin_app_name
    origin_dir = self._agent_origin_dir
    if not origin_name or origin_name.startswith('__'):
      self._app_name_alignment_hint = None
      return
    if origin_name == self.app_name:
      self._app_name_alignment_hint = None
      return
    origin_location = str(origin_dir) if origin_dir else origin_name
    mismatch_details = (
        'The runner is configured with app name '
        f'"{self.app_name}", but the root agent was loaded from '
        f'"{origin_location}", which implies app name "{origin_name}".'
    )
    resolution = (
        'Ensure the runner app_name matches that directory or pass app_name '
        'explicitly when constructing the runner.'
    )
    self._app_name_alignment_hint = f'{mismatch_details} {resolution}'
    logger.warning('App name mismatch detected. %s', mismatch_details)

  def _warn_uncached_agent_transfer(self) -> None:
    """Warns once per app when agent transfer runs with no context cache."""
    if self.context_cache_config is not None:
      return
    if self.app_name in _UNCACHED_TRANSFER_APPS:
      return
    if self.agent is None or not _can_transfer_between_agents(self.agent):
      return
    _UNCACHED_TRANSFER_APPS.add(self.app_name)
    logger.warning(
        'App "%s" can transfer between agents but has no'
        ' context_cache_config. Every transfer swaps the system instruction'
        ' and the tool set, so the request prefix changes and the whole'
        ' prompt is re-sent uncached after each transfer. Set'
        ' context_cache_config on the app to give each agent its own cache.',
        self.app_name,
    )

  def _resolve_invocation_id(
      self,
      session: Session,
      new_message: Optional[types.Content],
      invocation_id: Optional[str],
  ) -> Optional[str]:
    """Infers invocation_id from new_message if it is a function response."""
    if new_message is None:
      return invocation_id
    function_responses = _get_function_responses_from_content(new_message)
    if not function_responses:
      return invocation_id

    if not function_responses[0].id:
      raise ValueError(
          'Function response id is required to resume an invocation.'
      )
    # Resolve through the shared helper so every response in the message is
    # checked, not just the first one. A message answering several calls at
    # once (parallel tool calls) must resolve to a single invocation; taking
    # `function_responses[0]` alone would silently attribute the rest of the
    # responses to whichever invocation happened to come first.
    resolved_invocation_id = self._resolve_invocation_id_from_fr(
        session, new_message
    )

    if invocation_id and invocation_id != resolved_invocation_id:
      logger.warning(
          'Provided invocation_id %s is ignored because new_message has a '
          'function response with invocation_id %s.',
          invocation_id,
          resolved_invocation_id,
      )
    return resolved_invocation_id

  def _format_session_not_found_message(self, session_id: str) -> str:
    message = f'Session not found: {session_id}'
    if not self._app_name_alignment_hint:
      return message
    return (
        f'{message}. {self._app_name_alignment_hint} '
        'The mismatch prevents the runner from locating the session. '
        'To automatically create a session when missing, set '
        'auto_create_session=True when constructing the runner.'
    )

  async def _run_node_async(
      self,
      *,
      user_id: str,
      session_id: str,
      invocation_id: Optional[str] = None,
      new_message: Optional[types.Content] = None,
      state_delta: Optional[dict[str, Any]] = None,
      run_config: Optional[RunConfig] = None,
      yield_user_message: bool = False,
      node: BaseNode | None = None,
      session: Optional[Session] = None,
      abort_signal: Optional[asyncio.Event] = None,
  ) -> AsyncGenerator[Event, None]:
    """Run a BaseNode through NodeRunner.

    Events flow through ic._event_queue via NodeRunner.
    """
    from .workflow import _node_runner_utils

    async with aclosing(
        _node_runner_utils.run_node_async(
            self,
            user_id=user_id,
            session_id=session_id,
            invocation_id=invocation_id,
            new_message=new_message,
            state_delta=state_delta,
            run_config=run_config,
            yield_user_message=yield_user_message,
            node=node,
            session=session,
            abort_signal=abort_signal,
        )
    ) as agen:
      async for event in agen:
        yield event

  async def _run_node_live(
      self,
      *,
      session: Session,
      live_request_queue: LiveRequestQueue,
      run_config: Optional[RunConfig] = None,
  ) -> AsyncGenerator[Event, None]:
    """Run a non-agent BaseNode in live mode."""
    from .live import _runner_utils as _live_runner_utils

    async with aclosing(
        _live_runner_utils.run_node_live(
            self,
            session=session,
            live_request_queue=live_request_queue,
            run_config=run_config,
        )
    ) as agen:
      async for event in agen:
        yield event

  def _extract_resume_inputs(
      self, message: Optional[types.Content]
  ) -> dict[str, Any] | None:
    """Extract function response payloads from a message as resume_inputs."""
    if not message or not message.parts:
      return None
    inputs = {}
    for part in message.parts:
      if part.function_response and part.function_response.id:
        inputs[part.function_response.id] = part.function_response.response
    return inputs or None

  def _validate_new_message(
      self,
      message: Optional[types.Content],
      resume_inputs: dict[str, Any] | None,
  ) -> None:
    """Validate that new_message doesn't mix FR and text parts."""
    if not resume_inputs or not message or not message.parts:
      return
    if any(p.text for p in message.parts):
      raise ValueError(
          'Message cannot contain both function responses and text.'
          ' Function responses resume an existing invocation while'
          ' text starts a new one.'
      )

  def _resolve_invocation_id_from_fr(
      self,
      session: Session,
      new_message: types.Content,
      *,
      strict: bool = True,
  ) -> Optional[str]:
    """Infer invocation_id by matching function responses to FC events.

    When ``strict`` is True, raises ValueError if responses resolve to
    different invocations or any response id has no matching function call.
    When ``strict`` is False, returns None in those cases instead.
    """
    fr_ids = {
        p.function_response.id
        for p in new_message.parts or []
        if p.function_response and p.function_response.id
    }
    if not fr_ids:
      return None

    # Find invocation_id for each FR by matching its FC in session
    invocation_ids = set()
    for event in reversed(_apply_rewinds(session.events)):
      for fc in event.get_function_calls():
        if fc.id in fr_ids:
          invocation_ids.add(event.invocation_id)
          fr_ids.discard(fc.id)
      if not fr_ids:
        break

    if fr_ids:
      if not strict:
        return None
      raise ValueError(
          f'Function call not found for function response ids: {fr_ids}.'
          ' Ensure each function response ID matches an existing function'
          ' call in the session history.'
      )
    if len(invocation_ids) > 1:
      if not strict:
        return None
      raise ValueError(
          'Function responses resolve to multiple'
          f' invocations: {invocation_ids}. All function responses in a'
          ' single message must belong to the same invocation.'
      )
    return invocation_ids.pop() if invocation_ids else None

  async def _build_and_append_user_event(
      self,
      ic: InvocationContext,
      *,
      session: Optional[Session] = None,
      content: Optional[types.Content] = None,
      state_delta: Optional[dict[str, Any]] = None,
  ) -> Event:
    """Builds a user event, stamps context/isolation metadata, and appends it."""
    target_session = session or ic.session
    event_kwargs: dict[str, Any] = {
        'invocation_id': ic.invocation_id,
        'author': 'user',
    }
    if content is not None:
      event_kwargs['content'] = content
    if state_delta:
      event_kwargs['actions'] = EventActions(state_delta=state_delta)
    event = Event(**event_kwargs)
    # When a paused task delegation is in flight, stamp the new user message
    # with that task's isolation_scope so the task agent's content-build sees it.
    if event.isolation_scope is None:
      active_scope = _find_active_task_scope(target_session)
      if active_scope is not None:
        event.isolation_scope, _ = active_scope
    _apply_run_config_custom_metadata(event, ic.run_config)
    _stamp_event_branch_context(ic, event)
    return await self.session_service.append_event(
        session=target_session, event=event
    )

  async def _append_user_event(
      self,
      ic: InvocationContext,
      content: types.Content,
      *,
      state_delta: Optional[dict[str, Any]] = None,
  ) -> Event:
    """Append a user message event to the session and return it."""
    if content.parts and any(p.function_call for p in content.parts):
      raise ValueError('User message cannot contain function calls.')
    return await self._build_and_append_user_event(
        ic, content=content, state_delta=state_delta
    )

  async def _append_state_delta_event(
      self,
      ic: InvocationContext,
      state_delta: dict[str, Any],
  ) -> Event:
    """Appends an event to the session carrying only a state delta.

    Used when resuming an invocation without a new message, so that any
    caller-supplied state delta is still persisted to the session rather than
    being dropped because there is no new message event to attach it to.

    Args:
      ic: The invocation context for the run.
      state_delta: The state delta dictionary to append.

    Returns:
      The appended event, matching the return convention of
      the user message event.
    """
    return await self._build_and_append_user_event(ic, state_delta=state_delta)

  def _find_user_message_for_invocation(
      self, events: list[Event], invocation_id: str
  ) -> types.Content | None:
    """Finds the user message that started a specific invocation.

    A part carrying text anywhere in the message qualifies, not just the first
    one: a multimodal turn commonly leads with an image and puts the question
    after it, and requiring text in ``parts[0]`` would miss it. Resuming such an
    invocation used to fail outright, because the caller treats "not found" as
    an error.
    """
    for event in _apply_rewinds(events):
      if (
          event.invocation_id == invocation_id
          and event.author == 'user'
          and event.content
          and event.content.parts
          and not any(p.function_response for p in event.content.parts)
      ):
        return event.content
    return None

  async def _consume_event_queue(
      self, ic: InvocationContext, done_sentinel: object
  ) -> AsyncGenerator[Event, None]:
    """Consume events from ic._event_queue until done_sentinel."""
    event_queue: asyncio.Queue[_EventQueueItem] | None = ic._event_queue
    assert event_queue is not None
    if ic.is_aborted and event_queue.empty():
      return
    abort_task: asyncio.Task[bool] | None = None
    get_task: asyncio.Task[_EventQueueItem] | None = None
    try:
      while True:
        # Anything still queued after abort is dropped rather than drained,
        # except an event that a node produced before checking abort in the
        # same turn. A producer parked in _enqueue_event is released by
        # _cleanup_root_task, not by this loop.
        if ic.is_aborted and event_queue.empty():
          break
        if not event_queue.empty():
          event_or_done, processed_signal = event_queue.get_nowait()
        else:
          if abort_task is None or abort_task.done():
            abort_task = asyncio.create_task(
                ic._abort_signal.wait()  # pylint: disable=protected-access
            )
          get_task = asyncio.create_task(event_queue.get())
          done, _ = await asyncio.wait(
              [get_task, abort_task], return_when=asyncio.FIRST_COMPLETED
          )
          if not get_task.done():
            # Let get_task finish its step if event_queue.put() already resolved
            # its internal getter future in the same event-loop turn as abort().
            await asyncio.sleep(0)
          if not get_task.done():
            break
          event_or_done, processed_signal = get_task.result()
          get_task = None
        if event_or_done is done_sentinel:
          break
        if not isinstance(event_or_done, Event):
          raise TypeError(
              'Unexpected node event queue item:'
              f' {type(event_or_done).__name__}'
          )
        output_event = await self._process_event_with_plugin_callbacks(
            invocation_context=ic,
            event=event_or_done,
        )
        if not output_event.partial:
          if (
              output_event.node_info
              and output_event.node_info.message_as_output
              and output_event.content is not None
          ):
            output_event = output_event.model_copy()
            output_event.output = None
          await self.session_service.append_event(
              session=ic.session, event=output_event
          )
        yield output_event

        if isinstance(processed_signal, asyncio.Event):
          processed_signal.set()
    finally:
      pending_tasks = [
          t for t in (get_task, abort_task) if t is not None and not t.done()
      ]
      for t in pending_tasks:
        t.cancel()
      if pending_tasks:
        await asyncio.wait(pending_tasks)

  async def _cleanup_root_task(
      self,
      task: asyncio.Task[None],
      node_name: str,
  ) -> None:
    """Cancel the root task if still running, then await it.

    The task may still be running if the caller stopped iterating
    early (e.g., break in async for). In that case we must cancel
    to avoid a leaked task.

    Args:
      task: The root task to cancel and await.
      node_name: The name of the root node, used for logging.
    """
    cancelled_by_cleanup = False
    if not task.done():
      logger.debug(
          'Cancelling root node %s (caller stopped early).',
          node_name,
      )
      task.cancel()
      cancelled_by_cleanup = True
    try:
      await task
    except asyncio.CancelledError:
      if cancelled_by_cleanup:
        logger.info('Root node %s was cancelled.', node_name)
      else:
        # Root task was cancelled prior to cleanup.
        logger.warning(
            'Root node %s was cancelled by an external cancellation.',
            node_name,
        )
    except Exception:
      logger.error('Root node %s failed.', node_name, exc_info=True)
      raise

  async def _synthesize_abort_events_if_needed(
      self, ic: InvocationContext
  ) -> list[Event]:
    """Seals an aborted invocation in session history, at most once.

    Returns the synthetic events after plugin processing and persistence.
    """
    if ic._abort_state.event_synthesized or ic.session is None:  # pylint: disable=protected-access
      return []
    ic._abort_state.event_synthesized = True  # pylint: disable=protected-access
    abort_events = _build_abort_events(
        ic.session.events,
        invocation_id=ic.invocation_id,
        root_agent_name=self.agent.name,
        branch=ic.branch,
    )
    return [
        await self._process_and_append_event(event=e, invocation_context=ic)
        for e in abort_events
    ]

  async def _run_post_invocation_compaction(
      self,
      *,
      session: Session,
  ) -> None:
    """Run best-effort derived compaction after a completed invocation.

    A later turn is allowed to update the same session while summarization is
    running. If that happens, the old summary is discarded rather than making
    an already answered invocation fail. Raw events remain persisted and a
    later turn can re-evaluate compaction against its newer snapshot.
    """
    if not self.app or not self.app.events_compaction_config:
      return

    from google.adk.apps.compaction import _run_compaction_for_sliding_window

    logger.debug('Running event compactor.')
    try:
      async with aclosing(
          _run_compaction_for_sliding_window(
              self.app,
              session,
              self.session_service,
          )
      ) as compaction_events:
        async for compaction_event in compaction_events:
          await self.session_service.append_event(
              session=session, event=compaction_event
          )
    except StaleSessionError:
      logger.info(
          'Discarding stale post-invocation compaction for session %s; a'
          ' newer turn updated the session while summarization was running.',
          session.id,
      )

  async def _get_or_create_session(
      self,
      *,
      user_id: str,
      session_id: str,
      get_session_config: Optional[GetSessionConfig] = None,
  ) -> Session:
    """Gets the session or creates it if auto-creation is enabled.

    This helper first attempts to retrieve the session. If not found and
    auto_create_session is True, it creates a new session with the provided
    identifiers. Otherwise, it raises a SessionNotFoundError.

    Args:
      user_id: The user ID of the session.
      session_id: The session ID of the session.
      get_session_config: Optional configuration for controlling which events
        are fetched from session storage.

    Returns:
      The existing or newly created `Session`.

    Raises:
      SessionNotFoundError: If the session is not found and
        auto_create_session is False.
    """
    session = await self.session_service.get_session(
        app_name=self.app_name,
        user_id=user_id,
        session_id=session_id,
        config=get_session_config,
    )
    if not session:
      if self.auto_create_session:
        session = await self.session_service.create_session(
            app_name=self.app_name, user_id=user_id, session_id=session_id
        )
      else:
        message = self._format_session_not_found_message(session_id)
        raise SessionNotFoundError(message)
    return session

  def run(
      self,
      *,
      user_id: str,
      session_id: str,
      new_message: types.Content,
      state_delta: Optional[dict[str, Any]] = None,
      run_config: Optional[RunConfig] = None,
  ) -> Generator[Event, None, None]:
    """Runs the agent.

    NOTE:
      This sync interface is only for local testing and convenience purpose.
      Consider using `run_async` for production usage.

    If event compaction is enabled in the App configuration, it will be
    performed after all agent events for the current invocation have been
    yielded. The generator will only finish iterating after event
    compaction is complete.

    Args:
      user_id: The user ID of the session.
      session_id: The session ID of the session.
      new_message: A new message to append to the session.
      state_delta: Optional state changes to apply to the session.
      run_config: The run config for the agent.

    Yields:
      The events generated by the agent.

    Raises:
      Exception: Whatever the agent raised, re-raised on the calling thread
        once the events produced before the failure have been yielded. A
        failure that is not an Exception, such as a cancellation, is reported
        as a RuntimeError chained to it, because re-raising it here would tell
        the caller's own event loop that the caller was cancelled. Nothing is
        raised if the caller stops iterating before the run finishes.
    """
    run_config = run_config or RunConfig()
    event_queue: queue.Queue[Event | BaseException | None] = queue.Queue()
    # Handle to the background invocation, so that closing this generator early
    # can cancel it instead of leaking a running task. See
    # `_cleanup_root_task()` for the equivalent guarantee on `run_async()`.
    invocation_handle: queue.Queue[
        tuple[asyncio.AbstractEventLoop, Optional[asyncio.Task[Any]]]
    ] = queue.Queue(maxsize=1)
    caller_closed_early = False

    async def _invoke_run_async() -> None:
      invocation_handle.put(
          (asyncio.get_running_loop(), asyncio.current_task())
      )
      async with aclosing(
          self.run_async(
              user_id=user_id,
              session_id=session_id,
              new_message=new_message,
              state_delta=state_delta,
              run_config=run_config,
          )
      ) as agen:
        async for event in agen:
          event_queue.put(event)

    def _asyncio_thread_main() -> None:
      try:
        asyncio.run(_invoke_run_async())
      except BaseException as e:  # pylint: disable=broad-except
        # The failure surfaces only on this thread, and the agent may raise
        # anything, so forward it for the calling thread to report. This
        # catches BaseException because a cancelled run raises CancelledError,
        # which would otherwise be lost here.
        if not (isinstance(e, asyncio.CancelledError) and caller_closed_early):
          event_queue.put(e)
      finally:
        event_queue.put(None)

    # A new thread starts with empty contextvars. Run it in a copy of the
    # caller's so the invocation joins the caller's OpenTelemetry trace instead
    # of starting a disconnected one.
    thread = create_thread(contextvars.copy_context().run, _asyncio_thread_main)
    thread.start()

    exhausted = False
    agent_error: BaseException | None = None
    try:
      # consumes and re-yield the events from background thread.
      while True:
        item = event_queue.get()
        if item is None:
          exhausted = True
          break
        elif isinstance(item, BaseException):
          agent_error = item
          exhausted = True
          break
        else:
          yield item
    finally:
      if not exhausted:
        # Caller stopped iterating early; cancel background task with sentinel
        # so after_run callbacks still execute.
        caller_closed_early = True
        loop, task = invocation_handle.get()
        if task is not None:
          try:
            loop.call_soon_threadsafe(task.cancel, _CALLER_CLOSED_EARLY_MSG)
          except RuntimeError:
            # The background loop already finished; nothing to cancel.
            pass
      thread.join()

    if isinstance(agent_error, Exception):
      raise agent_error
    if agent_error is not None:
      # Re-raising a CancelledError here would read as the caller being
      # cancelled, and a SystemExit would end the caller's process.
      raise RuntimeError(
          f'Agent run terminated by {type(agent_error).__name__}.'
      ) from agent_error

  async def run_async(
      self,
      *,
      user_id: str,
      session_id: str,
      invocation_id: Optional[str] = None,
      new_message: Optional[types.Content] = None,
      state_delta: Optional[dict[str, Any]] = None,
      run_config: Optional[RunConfig] = None,
      yield_user_message: bool = False,
      abort_signal: Optional[asyncio.Event] = None,
  ) -> AsyncGenerator[Event, None]:
    """Main entry method to run the agent in this runner.

    If event compaction is enabled in the App configuration, it will be
    performed after all agent events for the current invocation have been
    yielded. The async generator will only finish iterating after event
    compaction is complete. However, this does not block new `run_async`
    calls for subsequent user queries, which can be started concurrently.

    Args:
      user_id: The user ID of the session.
      session_id: The session ID of the session.
      invocation_id: The invocation ID of the session, set this to resume an
        interrupted invocation.
      new_message: A new message to append to the session.
      state_delta: Optional state changes to apply to the session.
      run_config: The run config for the agent.
      yield_user_message: If True, yield the user message event before
        agent/node events.
      abort_signal: Optional asyncio.Event to cancel the invocation.

    Yields:
      The events generated by the agent.

    Note on Root LlmAgent in Task Mode:
      A root LlmAgent configured with `mode="task"` is fully supported. The
      runner drives it to completion via the finish_task tool and promotes the
      task result onto the terminal event's `output` field, which any caller can
      consume: a direct `run_async` caller reads it off the event stream, and
      the server-side `A2aAgentExecutor` wrapper turns it into an A2A artifact.

    Raises:
      ValueError: If the session is not found; If both invocation_id and
        new_message are None.
    """
    run_config = run_config or RunConfig()

    # An inbound message is always a user turn, whatever role the caller set,
    # matching the A2A request converter. Build a new Content instead of
    # assigning the role, so the caller's object is left unchanged and a
    # types.UserContent (whose role field is frozen) is accepted.
    if new_message and new_message.role != 'user':
      new_message = types.Content(role='user', parts=new_message.parts)

    from .agents.llm_agent import LlmAgent
    from .workflow._base_node import BaseNode

    if isinstance(self.agent, LlmAgent):
      # LlmAgent as root agent defaults to chat mode without mutating the
      # shared agent instance in place.
      effective_mode = self.agent.mode or _AgentMode.CHAT

      # A root LlmAgent runs in chat mode (the default) or task mode. Task mode
      # is fully supported for any caller: the agent runs to completion via the
      # finish_task tool and its result is promoted onto the terminal event's
      # output field (an A2A server turns that into an artifact; a direct caller
      # reads it off the event stream).
      if effective_mode in (_AgentMode.CHAT, _AgentMode.TASK):
        session = await self._get_or_create_session(
            user_id=user_id,
            session_id=session_id,
            get_session_config=run_config.get_session_config,
        )
        agent_to_run: BaseAgent
        if self._uses_legacy_sub_agent_picker():
          agent_to_run = self._find_agent_to_run(
              _session_for_routing(session, new_message), self.agent
          )
        else:
          agent_to_run = self.agent

        # The agent_to_run will be built/cloned inside Context.run_node,
        # so we don't call build_node here to avoid double cloning.
      else:
        raise ValueError(
            "LlmAgent as root agent must have mode='chat' or 'task', but got"
            f" mode='{effective_mode}'."
        )
      async with aclosing(
          self._run_node_async(
              user_id=user_id,
              session_id=session_id,
              invocation_id=invocation_id,
              new_message=new_message,
              state_delta=state_delta,
              run_config=run_config,
              yield_user_message=yield_user_message,
              node=agent_to_run,
              session=session,
              abort_signal=abort_signal,
          )
      ) as agen:
        async for event in agen:
          yield event
      return

    # TODO: remove `not isinstance(self.agent, BaseAgent)` after all agents are
    # refactored to use the node runtime path (requires adding tracing and plugins to it).
    if isinstance(self.agent, BaseNode) and not isinstance(
        self.agent, BaseAgent
    ):
      async with aclosing(
          self._run_node_async(
              user_id=user_id,
              session_id=session_id,
              invocation_id=invocation_id,
              new_message=new_message,
              state_delta=state_delta,
              run_config=run_config,
              yield_user_message=yield_user_message,
              abort_signal=abort_signal,
          )
      ) as agen:
        async for event in agen:
          yield event
      return

    root_agent = self._require_root_agent()

    async def _run_with_trace(
        new_message: Optional[types.Content] = None,
        invocation_id: Optional[str] = None,
    ) -> AsyncGenerator[Event, None]:
      session = await self._get_or_create_session(
          user_id=user_id,
          session_id=session_id,
          get_session_config=run_config.get_session_config,
      )

      if not invocation_id and new_message is None:
        raise ValueError(
            'Running an agent requires either a new_message or an '
            'invocation_id to resume a previous invocation. '
            f'Session: {session_id}, User: {user_id}'
        )

      is_resumable = (
          self.resumability_config and self.resumability_config.is_resumable
      )
      if not is_resumable:
        if new_message is None:
          raise ValueError(
              'Running an agent requires a new_message or a resumable app. '
              f'Session: {session_id}, User: {user_id}'
          )
        resolved_invocation_id = self._resolve_invocation_id_from_fr(
            session, new_message, strict=False
        )
        if resolved_invocation_id is not None:
          if invocation_id and invocation_id != resolved_invocation_id:
            logger.warning(
                'Provided invocation_id %s is ignored because new_message'
                ' has a function response with invocation_id %s.',
                invocation_id,
                resolved_invocation_id,
            )
          invocation_id = resolved_invocation_id
        invocation_context = await self._setup_context_for_new_invocation(
            session=session,
            new_message=new_message,
            run_config=run_config,
            state_delta=state_delta,
            invocation_id=invocation_id,
            abort_signal=abort_signal,
        )
      else:
        invocation_id = self._resolve_invocation_id(
            session, new_message, invocation_id
        )
        if not invocation_id:
          if new_message is None:
            raise ValueError(
                'A new message is required when no invocation can be resumed.'
            )
          invocation_context = await self._setup_context_for_new_invocation(
              session=session,
              new_message=new_message,
              run_config=run_config,
              state_delta=state_delta,
              abort_signal=abort_signal,
          )
        else:
          invocation_context = await self._setup_context_for_resumed_invocation(
              session=session,
              new_message=new_message,
              invocation_id=invocation_id,
              run_config=run_config,
              state_delta=state_delta,
              abort_signal=abort_signal,
          )
          active_agent = invocation_context.agent
          if not isinstance(active_agent, BaseAgent):
            raise RuntimeError(
                'Resumed agent execution has no active BaseAgent.'
            )
          if invocation_context.end_of_agents.get(active_agent.name):
            # Directly return if the current agent in invocation context is
            # already final.
            return

      invocation_context._abort_state.loop = asyncio.get_running_loop()  # pylint: disable=protected-access

      async def execute(
          ctx: InvocationContext,
      ) -> AsyncGenerator[Event, None]:
        if ctx.is_aborted:
          return
        active_agent = ctx.agent
        if not isinstance(active_agent, BaseAgent):
          raise RuntimeError('Agent execution has no active BaseAgent.')
        async with aclosing(active_agent.run_async(ctx)) as agen:
          async for event in agen:
            yield event
            if ctx.is_aborted:
              break

      async with aclosing(
          self._exec_with_plugin(
              invocation_context=invocation_context,
              session=invocation_context.session,
              execute_fn=execute,
              is_live_call=False,
          )
      ) as agen:
        async for event in agen:
          yield event
      if not invocation_context.is_aborted:
        # Run compaction after all events are yielded from the agent.
        # (We don't compact in the middle of an invocation, we only compact at
        # the end of an invocation.)
        await self._run_post_invocation_compaction(
            session=invocation_context.session,
        )

    from .telemetry import _instrumentation

    # For BaseAgent root agents running via _run_with_trace, events flow
    # through _run_with_trace which breaks cleanly upon abort.
    # Note that BaseNode/Workflow root targets are routed earlier via
    # _run_node_async, where Workflow and NodeRunner manage task cancellation
    # and queue-draining internally.
    # The invocation scope is opened out here rather than inside the generator,
    # so that its span is not opened and closed by whoever happens to drive the
    # generator, and `stream_in_scope` attaches it only while the generator is
    # actually running -- never across a yield (b/485899016).
    with _instrumentation.record_invocation(
        entrypoint_node=root_agent,
        conversation_id=session_id,
        run_config=run_config,
    ) as invocation_otel_context:
      async with aclosing(
          _instrumentation.stream_in_scope(
              invocation_otel_context,
              _run_with_trace(new_message, invocation_id),
          )
      ) as agen:
        async for event in agen:
          yield event

  async def rewind_async(
      self,
      *,
      user_id: str,
      session_id: str,
      rewind_before_invocation_id: str,
      run_config: Optional[RunConfig] = None,
  ) -> None:
    """Rewinds the session to before the specified invocation.

    Raises:
      InvocationNotFoundError: If rewind_before_invocation_id does not match
        any event in the session.
    """
    run_config = run_config or RunConfig()
    session = await self._get_or_create_session(
        user_id=user_id,
        session_id=session_id,
        get_session_config=run_config.get_session_config,
    )
    from .sessions import _rewind_utils

    await _rewind_utils.rewind_session(
        session_service=self.session_service,
        session=session,
        rewind_before_invocation_id=rewind_before_invocation_id,
        artifact_service=self.artifact_service,
        app_name=self.app_name,
        compute_state_delta=self._compute_state_delta_for_rewind,
        compute_artifact_delta=self._compute_artifact_delta_for_rewind,
    )

  async def _compute_state_delta_for_rewind(
      self, session: Session, rewind_event_index: int
  ) -> dict[str, Any]:
    """Computes the state delta to reverse changes."""
    from .sessions import _rewind_utils

    return await _rewind_utils.compute_state_delta_for_rewind(
        session, rewind_event_index
    )

  async def _compute_artifact_delta_for_rewind(
      self, session: Session, rewind_event_index: int
  ) -> dict[str, int]:
    """Computes the artifact delta to reverse changes."""
    from .sessions import _rewind_utils

    return await _rewind_utils.compute_artifact_delta_for_rewind(
        session,
        rewind_event_index,
        artifact_service=self.artifact_service,
        app_name=self.app_name,
    )

  def _should_append_event(self, event: Event, is_live_call: bool) -> bool:
    """Checks if an event should be appended to the session."""
    # Don't append media (audio/video/image) response from model in live mode to session.
    # The data is appended to artifacts with a reference in file_data in the
    # event if save_live_blob is True.
    # We should append non-partial events only.For example, non-finished(partial)
    # transcription events should not be appended.
    # Function call and function response events should be appended.
    # Other control events should be appended.
    if is_live_call:
      from .flows.llm_flows.context import _contents as contents

      if contents._is_live_model_media_event_with_inline_data(event):
        # We don't append live model media events with inline data to avoid
        # storing large blobs in the session. However, events with file_data
        # (references to artifacts) should be appended.
        return False
    return True

  def _get_output_event(
      self,
      *,
      original_event: Event,
      modified_event: Event | None,
      run_config: RunConfig | None,
  ) -> Event:
    """Returns the event that should be persisted and yielded.

    Plugins may return a replacement event that only overrides a subset of
    fields. Merge those changes onto the original event so the streamed event
    and the persisted event stay aligned without losing the original event
    identity.
    """
    if modified_event is None:
      return original_event

    _apply_run_config_custom_metadata(modified_event, run_config)
    update = {}
    for field_name in modified_event.model_fields_set:
      if field_name in {'id', 'invocation_id', 'timestamp'}:
        continue
      update[field_name] = modified_event.__dict__[field_name]
    internal = internal_metadata(original_event.custom_metadata)
    if 'custom_metadata' in update and internal:
      # ADK-internal keys belong to ADK, so a replacement cannot drop them.
      update['custom_metadata'] = {
          **(update['custom_metadata'] or {}),
          **internal,
      }
    output_event = original_event.model_copy(update=update)
    if not output_event.author:
      output_event.author = original_event.author
    return output_event

  async def _process_event_with_plugin_callbacks(
      self,
      *,
      invocation_context: InvocationContext,
      event: Event,
  ) -> Event:
    """Applies runner metadata and plugin callbacks to an output event."""
    _apply_run_config_custom_metadata(event, invocation_context.run_config)
    modified_event = (
        await invocation_context.plugin_manager.run_on_event_callback(
            invocation_context=invocation_context,
            event=event,
        )
    )
    return self._get_output_event(
        original_event=event,
        modified_event=modified_event,
        run_config=invocation_context.run_config,
    )

  async def _process_and_append_event(
      self,
      event: Event,
      invocation_context: InvocationContext,
      *,
      is_live_call: bool = False,
  ) -> Event:
    """Applies custom metadata, runs on_event callbacks, and appends to session."""
    output_event = await self._process_event_with_plugin_callbacks(
        invocation_context=invocation_context,
        event=event,
    )

    if is_live_call:
      if output_event.partial is not True and self._should_append_event(
          output_event, is_live_call
      ):
        logger.debug('Appending live event: %s', output_event)
        await self.session_service.append_event(
            session=invocation_context.session, event=output_event
        )
    else:
      if output_event.partial is not True:
        await self.session_service.append_event(
            session=invocation_context.session, event=output_event
        )
    return output_event

  async def _exec_with_plugin(
      self,
      invocation_context: InvocationContext,
      session: Session,
      execute_fn: Callable[[InvocationContext], AsyncGenerator[Event, None]],
      is_live_call: bool = False,
  ) -> AsyncGenerator[Event, None]:
    """Wraps execution with plugin callbacks.

    Args:
      invocation_context: The invocation context
      session: The current session (ignored, kept for backward compatibility)
      execute_fn: A callable that returns an AsyncGenerator of Events
      is_live_call: Whether this is a live call

    Yields:
      Events from the execution, including any generated by plugins
    """

    plugin_manager = invocation_context.plugin_manager
    run_error: BaseException | None = None
    closing_early = False

    try:
      # Step 1: Run the before_run callbacks to see if we should early exit.
      early_exit_result = await plugin_manager.run_before_run_callback(
          invocation_context=invocation_context
      )
      if isinstance(early_exit_result, types.Content):
        early_exit_event = Event(
            invocation_id=invocation_context.invocation_id,
            author='model',
            content=early_exit_result,
        )
        yield await self._process_and_append_event(
            event=early_exit_event,
            invocation_context=invocation_context,
            is_live_call=is_live_call,
        )
      else:
        # Step 2: Otherwise continue with normal execution
        async with aclosing(execute_fn(invocation_context)) as agen:
          async for event in agen:
            output_event = await self._process_and_append_event(
                event=event,
                invocation_context=invocation_context,
                is_live_call=is_live_call,
            )
            yield output_event
        if not is_live_call and invocation_context.is_aborted:
          abort_events = await self._synthesize_abort_events_if_needed(
              invocation_context
          )
          for abort_event in abort_events:
            yield abort_event
    except GeneratorExit:
      # Early generator close is treated as a clean completion.
      closing_early = True
      raise
    except Exception as e:
      run_error = e
      # Notify plugins of the unhandled execution error. Covers failures in
      # before_run_callback, early-exit, and the main execution loop.
      # Notification-only; the original exception is always re-raised.
      await _notify_run_error(plugin_manager, invocation_context, e)
      raise
    except asyncio.CancelledError as e:
      if (
          e.args and e.args[0] == _CALLER_CLOSED_EARLY_MSG
      ) or invocation_context.is_aborted:
        closing_early = True
      else:
        run_error = e
      raise
    except BaseException as e:
      # Interrupts or aborts; skip after_run callbacks.
      run_error = e
      raise
    finally:
      if not is_live_call and invocation_context.is_aborted:
        # Best-effort: only reached on early close or error, where raising
        # would mask the in-flight exception and skip after_run.
        try:
          await self._synthesize_abort_events_if_needed(invocation_context)
        except Exception:  # pylint: disable=broad-exception-caught
          logger.error(
              'Failed to seal aborted invocation %s.',
              invocation_context.invocation_id,
              exc_info=True,
          )
      # Step 4: Run after_run callbacks on successful completion or early exit.
      if run_error is None:
        try:
          await plugin_manager.run_after_run_callback(
              invocation_context=invocation_context
          )
        except Exception as e:
          await _notify_run_error(plugin_manager, invocation_context, e)
          if closing_early:
            # Avoid masking the in-flight GeneratorExit or early-exit cancellation.
            logger.error(
                'after_run callback failed while closing invocation %s early.',
                invocation_context.invocation_id,
                exc_info=True,
            )
          else:
            raise

  async def _append_new_message_to_session(
      self,
      *,
      session: Optional[Session] = None,
      new_message: types.Content,
      invocation_context: InvocationContext,
      save_input_blobs_as_artifacts: bool = False,
      state_delta: Optional[dict[str, Any]] = None,
  ) -> None:
    """Appends a new message to the session.

    Args:
        session: The session to append the message to (optional, defaults to
          invocation_context.session).
        new_message: The new message to append.
        invocation_context: The invocation context for the message.
        save_input_blobs_as_artifacts: Whether to save input blobs as artifacts.
        state_delta: Optional state changes to apply to the session.
    """
    target_session = session or invocation_context.session
    if not new_message.parts:
      raise ValueError('No parts in the new_message.')

    if any(p.function_call for p in new_message.parts):
      raise ValueError('User message cannot contain function calls.')

    if self.artifact_service and save_input_blobs_as_artifacts:
      # Issue deprecation warning
      warnings.warn(
          "The 'save_input_blobs_as_artifacts' parameter is deprecated. Use"
          ' SaveFilesAsArtifactsPlugin instead for better control and'
          ' flexibility. See google.adk.plugins.SaveFilesAsArtifactsPlugin for'
          ' migration guidance.',
          DeprecationWarning,
          stacklevel=3,
      )
      # The runner directly saves the artifacts (if applicable) in the
      # user message and replaces the artifact data with a file name
      # placeholder.
      for i, part in enumerate(new_message.parts):
        if part.inline_data is None:
          continue
        file_name = f'artifact_{invocation_context.invocation_id}_{i}'
        await self.artifact_service.save_artifact(
            app_name=self.app_name,
            user_id=target_session.user_id,
            session_id=target_session.id,
            filename=file_name,
            artifact=part,
        )
        new_message.parts[i] = types.Part(
            text=f'Uploaded file: {file_name}. It is saved into artifacts'
        )
    # Appends only. We do not yield the event because it's not from the model.
    await self._build_and_append_user_event(
        invocation_context,
        session=target_session,
        content=new_message,
        state_delta=state_delta,
    )

  async def run_live(
      self,
      *,
      user_id: Optional[str] = None,
      session_id: Optional[str] = None,
      live_request_queue: LiveRequestQueue,
      run_config: Optional[RunConfig] = None,
      session: Optional[Session] = None,
  ) -> AsyncGenerator[Event, None]:
    """Runs the agent in live mode (experimental feature).

    The `run_live` method yields a stream of `Event` objects, but not all
    yielded events are saved to the session. Here's a breakdown:

    **Events Yielded to Callers:**
    *   **Live Model Audio Events with Inline Data:** Events containing raw
        audio `Blob` data(`inline_data`).
    *   **Live Model Audio Events with File Data:** Both input and output audio
        data are aggregated into an audio file saved into artifacts. The
        reference to the file is saved in the event as `file_data`.
    *   **Usage Metadata:** Events containing token usage.
    *   **Transcription Events:** Both partial and non-partial transcription
        events are yielded.
    *   **Function Call and Response Events:** Always saved.
    *   **Other Control Events:** Most control events are saved.

    **Events Saved to the Session:**
    *   **Live Model Audio Events with File Data:** Both input and output audio
        data are aggregated into an audio file saved into artifacts. The
        reference to the file is saved as event in the `file_data` to session
        if RunConfig.save_live_model_audio_to_session is True.
    *   **Usage Metadata Events:** Saved to the session.
    *   **Non-Partial Transcription Events:** Non-partial transcription events
        are saved.
    *   **Function Call and Response Events:** Always saved.
    *   **Other Control Events:** Most control events are saved.

    **Events Not Saved to the Session:**
    *   **Live Model Audio Events with Inline Data:** Events containing raw
        audio `Blob` data are **not** saved to the session.

    Args:
        user_id: The user ID for the session. Required if `session` is None.
        session_id: The session ID for the session. Required if `session` is
          None.
        live_request_queue: The queue for live requests.
        run_config: The run config for the agent.
        session: The session to use. This parameter is deprecated, please use
          `user_id` and `session_id` instead.

    Yields:
        AsyncGenerator[Event, None]: An asynchronous generator that yields
        `Event`
        objects as they are produced by the agent during its live execution.

    .. warning::
        This feature is **experimental** and its API or behavior may change
        in future releases.

    .. NOTE::
        Either `session` or both `user_id` and `session_id` must be provided.
    """

    from .live import _runner_utils as _live_runner_utils

    async with aclosing(
        _live_runner_utils.run_live(
            self,
            user_id=user_id,
            session_id=session_id,
            live_request_queue=live_request_queue,
            run_config=run_config,
            session=session,
        )
    ) as agen:
      async for event in agen:
        yield event

  def _uses_legacy_sub_agent_picker(self) -> bool:
    """Returns whether chat-mode root LlmAgent uses the legacy sub-agent picker."""
    from .agents.llm_agent import LlmAgent  # pylint: disable=g-import-not-at-top

    if (
        not isinstance(self.agent, LlmAgent)
        or (self.agent.mode or _AgentMode.CHAT) != _AgentMode.CHAT
    ):
      return False
    remote_a2a_agent_class: tuple[Any, ...] = ()
    try:
      from .agents.remote_a2a_agent import RemoteA2aAgent  # pylint: disable=g-import-not-at-top

      remote_a2a_agent_class = (RemoteA2aAgent,)
    except ImportError:
      pass
    return not any(
        isinstance(sa, (LlmAgent,) + remote_a2a_agent_class)
        and getattr(sa, 'mode', None) == _AgentMode.TASK
        for sa in self.agent.sub_agents or []
    )

  def _find_agent_to_run(
      self, session: Session, root_agent: BaseAgent
  ) -> BaseAgent:
    """Finds the agent to run to continue the session.

    A qualified agent must be either of:

    - The agent that returned a function call and the last user message is a
      function response to this function call.
    - The root agent.
    - An LlmAgent who replied last and is capable to transfer to any other agent
      in the agent hierarchy.

    Args:
        session: The session to find the agent for.
        root_agent: The root agent of the runner.

    Returns:
      The agent to run. (the active agent that should reply to the latest user
      message)
    """
    from .agents import _agent_router

    return _agent_router.find_agent_to_run(
        session=session,
        root_agent=root_agent,
        resumability_config=self.resumability_config,
    )

  async def run_debug(
      self,
      user_messages: str | list[str],
      *,
      user_id: str = 'debug_user_id',
      session_id: str = 'debug_session_id',
      run_config: RunConfig | None = None,
      quiet: bool = False,
      verbose: bool = False,
  ) -> list[Event]:
    """Debug helper for quick agent experimentation and testing.

    This convenience method is designed for developers getting started with ADK
    who want to quickly test agents without dealing with session management,
    content formatting, or event streaming. It automatically handles common
    boilerplate while hiding complexity.

    IMPORTANT: This is for debugging and experimentation only. For production
    use, please use the standard run_async() method which provides full control
    over session management, event streaming, and error handling.

    Args:
        user_messages: Message(s) to send to the agent. Can be: - Single string:
          "What is 2+2?" - List of strings: ["Hello!", "What's my name?"]
        user_id: User identifier. Defaults to "debug_user_id".
        session_id: Session identifier for conversation persistence. Defaults to
          "debug_session_id". Reuse the same ID to continue a conversation.
        run_config: Optional configuration for the agent execution.
        quiet: If True, suppresses console output. Defaults to False (output
          shown).
        verbose: If True, shows detailed tool calls and responses. Defaults to
          False for cleaner output showing only final agent responses.

    Returns:
        list[Event]: All events from all messages.

    Raises:
        ValueError: If session creation/retrieval fails.

    Examples:
        Quick debugging:
        >>> runner = InMemoryRunner(agent=my_agent)
        >>> await runner.run_debug("What is 2+2?")

        Multiple queries in conversation:
        >>> await runner.run_debug(["Hello!", "What's my name?"])

        Continue a debug session:
        >>> await runner.run_debug("What did we discuss?")  # Continues default
        session

        Separate debug sessions:
        >>> await runner.run_debug("Hi", user_id="alice", session_id="debug1")
        >>> await runner.run_debug("Hi", user_id="bob", session_id="debug2")

        Capture events for inspection:
        >>> events = await runner.run_debug("Analyze this")
        >>> for event in events:
        ...     inspect_event(event)

    Note:
        For production applications requiring:
        - Custom session/memory services (Spanner, Cloud SQL, etc.)
        - Fine-grained event processing and streaming
        - Error recovery and resumability
        - Performance optimization
        Please use run_async() with proper configuration.
    """
    run_config = run_config or RunConfig()
    session = await self.session_service.get_session(
        app_name=self.app_name,
        user_id=user_id,
        session_id=session_id,
        config=run_config.get_session_config,
    )
    if not session:
      session = await self.session_service.create_session(
          app_name=self.app_name, user_id=user_id, session_id=session_id
      )
      if not quiet:
        logger.info('Created new session: %s', session_id)
    elif not quiet:
      logger.info('Continue session: %s', session_id)

    collected_events: list[Event] = []

    if isinstance(user_messages, str):
      user_messages = [user_messages]

    for message in user_messages:
      if not quiet:
        logger.info('User > %s', message)

      async with aclosing(
          self.run_async(
              user_id=user_id,
              session_id=session.id,
              new_message=types.UserContent(parts=[types.Part(text=message)]),
              run_config=run_config,
          )
      ) as agen:
        async for event in agen:
          if not quiet:
            print_event(event, verbose=verbose)

          collected_events.append(event)

    return collected_events

  def _restore_branch_from_history(
      self,
      invocation_context: InvocationContext,
      node: BaseNode,
      *,
      root: BaseNode,
      invocation_id: Optional[str] = None,
  ) -> None:
    """Restores a non-root node's branch from its latest matching event."""
    from .agents import _agent_router

    _agent_router.restore_branch_from_history(
        invocation_context=invocation_context,
        node=node,
        root=root,
        invocation_id=invocation_id,
    )

  async def _setup_context_for_new_invocation(
      self,
      *,
      session: Session,
      new_message: types.Content,
      run_config: RunConfig,
      state_delta: Optional[dict[str, Any]],
      invocation_id: Optional[str] = None,
      abort_signal: Optional[asyncio.Event] = None,
  ) -> InvocationContext:
    """Sets up the context for a new invocation.

    Args:
      session: The session to set up the invocation context for.
      new_message: The new message to process and append to the session.
      run_config: The run config of the agent.
      state_delta: Optional state changes to apply to the session.
      invocation_id: Optional invocation identifier.
      abort_signal: Optional abort signal to cancel this invocation.

    Returns:
      The invocation context for the new invocation.
    """
    # Step 1: Create invocation context in memory.
    invocation_context = self._new_invocation_context(
        session,
        new_message=new_message,
        run_config=run_config,
        invocation_id=invocation_id,
    )
    if abort_signal is not None:
      # Attached here rather than passed to `_new_invocation_context`, whose
      # signature subclasses override. Safe at this point because nothing has
      # derived a sub-context from this one yet.
      invocation_context._attach_abort_signal(abort_signal)
    # Step 2: Handle new message, by running callbacks and appending to
    # session.
    await self._handle_new_message(
        new_message=new_message,
        invocation_context=invocation_context,
        run_config=run_config,
        state_delta=state_delta,
    )
    # Step 3: Set agent to run for the invocation.
    root_agent = self._require_root_agent()
    invocation_context.agent = self._find_agent_to_run(
        invocation_context.session, root_agent
    )
    if invocation_context.agent and invocation_context.agent is not root_agent:
      fr_invocation_id = self._resolve_invocation_id_from_fr(
          invocation_context.session,
          invocation_context.user_content or new_message,
          strict=False,
      )
      self._restore_branch_from_history(
          invocation_context,
          invocation_context.agent,
          root=root_agent,
          invocation_id=fr_invocation_id,
      )
    return invocation_context

  async def _setup_context_for_resumed_invocation(
      self,
      *,
      session: Session,
      new_message: Optional[types.Content],
      invocation_id: str,
      run_config: RunConfig,
      state_delta: Optional[dict[str, Any]],
      abort_signal: Optional[asyncio.Event] = None,
  ) -> InvocationContext:
    """Sets up the context for a resumed invocation.

    Args:
      session: The session to set up the invocation context for.
      new_message: The new message to process and append to the session.
      invocation_id: The invocation id to resume.
      run_config: The run config of the agent.
      state_delta: Optional state changes to apply to the session.
      abort_signal: Optional abort signal to cancel this invocation.

    Returns:
      The invocation context for the resumed invocation.

    Raises:
      ValueError: If the session has no events to resume; If no user message is
        available for resuming the invocation; Or if the app is not resumable.
    """
    if not session.events:
      raise ValueError(f'Session {session.id} has no events to resume.')

    # Step 1: Maybe retrieve a previous user message for the invocation.
    user_message = new_message or self._find_user_message_for_invocation(
        session.events, invocation_id
    )
    if not user_message:
      raise ValueError(
          f'No user message available for resuming invocation: {invocation_id}'
      )
    # Step 2: Create invocation context.
    invocation_context = self._new_invocation_context(
        session,
        new_message=user_message,
        run_config=run_config,
        invocation_id=invocation_id,
    )
    if abort_signal is not None:
      # See `_setup_context_for_new_invocation` for why this is attached
      # after construction rather than passed to the factory.
      invocation_context._attach_abort_signal(abort_signal)
    # Step 3: Maybe handle new message.
    if new_message:
      await self._handle_new_message(
          new_message=user_message,
          invocation_context=invocation_context,
          run_config=run_config,
          state_delta=state_delta,
      )
    elif state_delta:
      # Resuming without a new message: there is no user message event to
      # carry the delta, so append it as a content-less event instead of
      # dropping it.
      await self._append_state_delta_event(invocation_context, state_delta)
    # Step 4: Populate agent states for the current invocation.
    invocation_context.populate_invocation_agent_states()
    # Step 5: Set agent to run for the invocation.
    #
    # If the root agent is not found in end_of_agents, it means the invocation
    # started from a sub-agent and paused on a sub-agent.
    # We should find the appropriate agent to run to continue the invocation.
    root_agent = self._require_root_agent()
    if root_agent.name not in invocation_context.end_of_agents:
      invocation_context.agent = self._find_agent_to_run(
          invocation_context.session, root_agent
      )
      if (
          invocation_context.agent
          and invocation_context.agent is not root_agent
      ):
        self._restore_branch_from_history(
            invocation_context,
            invocation_context.agent,
            root=root_agent,
            invocation_id=invocation_context.invocation_id,
        )
    return invocation_context

  def _create_invocation_context(self, **kwargs: object) -> InvocationContext:
    """Creates an InvocationContext instance."""
    return InvocationContext(**kwargs)

  def _new_invocation_context(
      self,
      session: Session,
      *,
      invocation_id: Optional[str] = None,
      new_message: Optional[types.Content] = None,
      live_request_queue: Optional[LiveRequestQueue] = None,
      run_config: Optional[RunConfig] = None,
  ) -> InvocationContext:
    """Creates a new invocation context.

    This is an extension point that subclasses override to build their own
    context type, so its signature is kept stable. A caller-supplied abort
    signal is attached to the returned context by the caller rather than
    threaded through here, because adding a parameter would raise TypeError in
    every existing override.

    Args:
        session: The session for the context.
        invocation_id: The invocation id for the context.
        new_message: The new message for the context.
        live_request_queue: The live request queue for the context.
        run_config: The run config for the context.

    Returns:
        The new invocation context.
    """
    run_config = run_config or RunConfig()
    invocation_id = invocation_id or new_invocation_context_id()

    if run_config.support_cfc and hasattr(self.agent, 'canonical_model'):
      from .agents.llm_agent import LlmAgent

      cfc_agent = cast(LlmAgent, self.agent)
      model_name = cfc_agent.canonical_model.model
      if not model_name.startswith('gemini-2'):
        raise ValueError(
            f'CFC is not supported for model: {model_name} in agent:'
            f' {cfc_agent.name}'
        )

    return self._create_invocation_context(
        artifact_service=self.artifact_service,
        session_service=self.session_service,
        memory_service=self.memory_service,
        credential_service=self.credential_service,
        plugin_manager=self.plugin_manager,
        context_cache_config=self.context_cache_config,
        events_compaction_config=(
            self.app.events_compaction_config if self.app else None
        ),
        invocation_id=invocation_id,
        agent=self.agent if isinstance(self.agent, BaseAgent) else None,
        session=session,
        user_content=new_message,
        live_request_queue=live_request_queue,
        run_config=run_config,
        resumability_config=self.resumability_config,
    )

  async def _handle_new_message(
      self,
      *,
      new_message: types.Content,
      invocation_context: InvocationContext,
      run_config: RunConfig,
      state_delta: Optional[dict[str, Any]],
  ) -> None:
    """Handles a new message by running callbacks and appending to session.

    The session is reached through ``invocation_context.session``.

    Args:
      new_message: The new message to process and append to the session.
      invocation_context: The invocation context to use for the message
        handling.
      run_config: The run config of the agent.
      state_delta: Optional state changes to apply to the session.
    """
    is_function_response = bool(
        new_message.parts
        and any(p.function_response for p in new_message.parts)
    )
    if not is_function_response and self._find_user_message_for_invocation(
        invocation_context.session.events, invocation_context.invocation_id
    ):
      return

    modified_user_message = (
        await invocation_context.plugin_manager.run_on_user_message_callback(
            invocation_context=invocation_context, user_message=new_message
        )
    )
    if modified_user_message is not None:
      new_message = modified_user_message
      invocation_context.user_content = new_message

    if new_message:
      deprecated_save_blobs = False
      if 'save_input_blobs_as_artifacts' in run_config.model_fields_set:
        deprecated_save_blobs = run_config.save_input_blobs_as_artifacts
      await self._append_new_message_to_session(
          session=invocation_context.session,
          new_message=new_message,
          invocation_context=invocation_context,
          save_input_blobs_as_artifacts=deprecated_save_blobs,
          state_delta=state_delta,
      )

  def _collect_toolset(
      self, root: BaseNode, visited: set[int] | None = None
  ) -> set[BaseToolset]:
    if not isinstance(root, BaseNode):
      return set()
    if visited is None:
      visited = set()
    root_id = id(root)
    if root_id in visited:
      return set()
    visited.add(root_id)

    toolsets: set[BaseToolset] = set()
    if hasattr(root, 'tools'):
      for tool_union in getattr(root, 'tools', ()) or ():
        if isinstance(tool_union, BaseToolset):
          toolsets.add(tool_union)
    if hasattr(root, 'sub_agents'):
      for sub_agent in getattr(root, 'sub_agents', ()) or ():
        toolsets.update(self._collect_toolset(sub_agent, visited))
    if hasattr(root, 'graph') and getattr(root, 'graph', None):
      graph = getattr(root, 'graph')
      nodes = getattr(graph, 'nodes', None)
      if nodes:
        node_iter = nodes.values() if isinstance(nodes, dict) else nodes
        for node in node_iter:
          toolsets.update(self._collect_toolset(node, visited))
    if hasattr(root, '_node') and getattr(root, '_node', None):
      toolsets.update(self._collect_toolset(getattr(root, '_node'), visited))
    if hasattr(root, '_inner_node') and getattr(root, '_inner_node', None):
      toolsets.update(
          self._collect_toolset(getattr(root, '_inner_node'), visited)
      )
    return toolsets

  async def _cleanup_toolsets(
      self, toolsets_to_close: set[BaseToolset]
  ) -> None:
    """Clean up toolsets with proper task context management."""
    if not toolsets_to_close:
      return

    # This maintains the same task context throughout cleanup
    for toolset in toolsets_to_close:
      cleanup_task = asyncio.create_task(
          asyncio.wait_for(toolset.close(), timeout=10.0)
      )
      try:
        logger.info('Closing toolset: %s', type(toolset).__name__)
        await asyncio.shield(cleanup_task)
        logger.info('Successfully closed toolset: %s', type(toolset).__name__)
      except asyncio.TimeoutError:
        logger.warning('Toolset %s cleanup timed out', type(toolset).__name__)
      except asyncio.CancelledError as e:
        # Handle cancel scope issues in Python 3.10 and 3.11 with anyio
        #
        # Root cause: MCP library uses anyio.CancelScope() in RequestResponder.__enter__()
        # and __exit__() methods. When asyncio.wait_for() creates a new task for cleanup,
        # the cancel scope is entered in one task context but exited in another.
        #
        # Python 3.12+ fixes: Enhanced task context management (Task.get_context()),
        # improved context propagation across task boundaries, and better cancellation
        # handling prevent the cross-task cancel scope violation.
        logger.warning(
            'Toolset %s cleanup cancellation requested: %s',
            type(toolset).__name__,
            e,
        )
        try:
          await cleanup_task
          logger.info(
              'Successfully closed toolset after cancellation request: %s',
              type(toolset).__name__,
          )
        except asyncio.TimeoutError:
          cleanup_task.cancel()
          logger.warning(
              'Toolset %s cleanup timed out after cancellation request',
              type(toolset).__name__,
          )
        except asyncio.CancelledError as close_cancelled:
          logger.warning(
              'Toolset %s cleanup cancelled: %s',
              type(toolset).__name__,
              close_cancelled,
          )
        except Exception as close_error:
          logger.error(
              'Error closing toolset %s after cancellation request: %s',
              type(toolset).__name__,
              close_error,
          )
        raise
      except Exception as e:
        logger.error('Error closing toolset %s: %s', type(toolset).__name__, e)

  async def close(self) -> None:
    """Closes the runner."""
    logger.info('Closing runner...')
    # Close Toolsets
    if self.agent is not None:
      await self._cleanup_toolsets(self._collect_toolset(self.agent))

    # Close Plugins
    if self.plugin_manager:
      await self.plugin_manager.close()

    # Close Session Service
    if self.session_service:
      await self.session_service.flush()

    logger.info('Runner closed.')

  async def __aenter__(self) -> Self:
    """Async context manager entry."""
    return self

  async def __aexit__(
      self,
      exc_type: type[BaseException] | None,
      exc_val: BaseException | None,
      exc_tb: TracebackType | None,
  ) -> Literal[False]:
    """Async context manager exit."""
    await self.close()
    return False  # Don't suppress exceptions from the async with block


class InMemoryRunner(Runner):
  """An in-memory Runner for testing and development.

  This runner uses in-memory implementations for artifact, session, and memory
  services, providing a lightweight and self-contained environment for agent
  execution.

  Attributes:
      agent: The root agent to run.
      app_name: The application name of the runner. Defaults to
        'InMemoryRunner'.
  """

  def __init__(
      self,
      agent: Optional[BaseAgent] = None,
      *,
      node: BaseNode | None = None,
      app_name: Optional[str] = None,
      plugins: Optional[list[BasePlugin]] = None,
      app: Optional[App] = None,
      plugin_close_timeout: float = 5.0,
  ) -> None:
    """Initializes the InMemoryRunner.

    Args:
        agent: The root agent to run.
        node: The root node to run.
        app_name: The application name of the runner. Defaults to
          'InMemoryRunner'.
        plugins: Optional list of plugins for the runner.
        app: Optional App instance.
        plugin_close_timeout: The timeout in seconds for plugin close methods.
    """
    from .artifacts.in_memory_artifact_service import InMemoryArtifactService
    from .memory.in_memory_memory_service import InMemoryMemoryService
    from .sessions.in_memory_session_service import InMemorySessionService

    if app is None and app_name is None:
      app_name = 'InMemoryRunner'
    super().__init__(
        app_name=app_name,
        agent=agent,
        node=node,
        artifact_service=InMemoryArtifactService(),
        plugins=plugins,
        app=app,
        session_service=InMemorySessionService(),
        memory_service=InMemoryMemoryService(),
        plugin_close_timeout=plugin_close_timeout,
    )


if not TYPE_CHECKING:
  __getattr__, __dir__ = _lazy.accessors(
      globals(), {'tracer': 'google.adk.telemetry.tracing'}
  )
